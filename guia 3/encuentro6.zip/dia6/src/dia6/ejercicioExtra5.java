/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia6;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicioExtra5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        System.out.println("ingrese tipo de socio A/B/C");
        String letra = leer.nextLine();
        int tratamiento = (int) (Math.random() * 3000);
        
        switch (letra){
            case "a" :
                System.out.println("el costo del tratamiento es de : "+tratamiento+" ,con descuento de socio A: "+tratamiento * 0.5);
                break;
            case "b" :
                System.out.println("el costo del tratamiento es de : "+tratamiento+" ,con descuento de socio B: "+tratamiento * 0.35);
                break;
            case "c" :
                System.out.println("el costo del tratamiento es de : "+tratamiento);
                break;
        }
    }
    
}
