/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia6;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicioExtra8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int num;
        
        do{
            System.out.println("ingrese un valor");
            num = leer.nextInt();
            
            
        }while(num/5 == 0);
    }
    
}
