/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia6;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class correccion6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada=new Scanner(System.in);
        int cantidadPersonas, cantidadPersonasBajas;
        double altura, sumaAlturasBajas, sumaALturasTotales;
        
        cantidadPersonasBajas=0;
        sumaAlturasBajas=0;
        sumaALturasTotales=0;
        cantidadPersonas = 4;
        
        for (int i = 0; i < cantidadPersonas; i++) {
            System.out.println("Ingresar la altura de la persona "+i);
            altura=entrada.nextDouble();
            sumaALturasTotales+=altura;
            if (altura<1.6){
                cantidadPersonasBajas++;
                sumaAlturasBajas+=altura;
                
            }
        }
        System.out.println(sumaALturasTotales);
        System.out.println(cantidadPersonas);
        System.out.println(sumaAlturasBajas);
        System.out.println(cantidadPersonasBajas);
        System.out.println("El promedio de alturas totales es "+sumaALturasTotales/cantidadPersonas);
        System.out.println("El promedio de alturas por debajo de 1.6 es "+sumaAlturasBajas/cantidadPersonasBajas);
    }
    
}
