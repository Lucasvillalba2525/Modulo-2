/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia6;

/**
 *
 * @author User
 */
public class ejercicioExtra2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int aux, numA ,numB ,numC ,numD;
        numA = 1;
        numB = 2;
        numC = 3;
        numD = 4;
        System.out.println("los valores iniciales son : A="+numA+" B="+numB+" C="+numC+" D="+numD);
        aux = numB;
        numB = numC;
        numC = numA;
        numA = numD;
        numD = aux;
        System.out.println("los valores finales son : A="+numA+" B="+numB+" C="+numC+" D="+numD);
    }
    
}
