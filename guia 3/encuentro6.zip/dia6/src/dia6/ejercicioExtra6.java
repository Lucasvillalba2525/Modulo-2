/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia6;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicioExtra6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        double altura, promedio,sumaT ,sumaB,total,totalB;
        int contB ,contA;
        contB = 0;
        contA = 0;
        sumaT = 0;
        sumaB = 0;
        
        for (int i = 0;i < 4 ; i++){
            System.out.println("ingrese la altura de la persona "+i);
            altura = leer.nextDouble();
            
            sumaT += altura;
            contA += 1;
                
            if (altura < 1.60){
                sumaB += altura;
                contB += 1;
            }
        }
        totalB = sumaB /contB;
        total = sumaT /contA;
        System.out.println("el promedio de estaturas de personas por debajo del 1.60 es : "+Math.round(totalB));
        System.out.println("el promedio de estaturas de las personas ingresadas es : "+total);
    }
    
}
