/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia.pkg4;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicioMayor25 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer=new Scanner (System.in);
       int num1;
       int num2;
        System.out.println("Escriba el 1° número");
       num1=leer.nextInt();
        System.out.println("Escriba el 2° número");
       num2=leer.nextInt();
       
       if (num1>25 && num2>25) {
            System.out.println("ambos números son mayores a 25");
          
         }   
       else if (num1>25) {
            System.out.println("el número "+num1+" es mayor a 25");
    
        } 
       else if (num2>25) {
            System.out.println("el número "+num2+" es mayor a 25");
                   
        } 
       else {
            System.out.println("ningún número es mayor a 25");
       
       }
    }
}