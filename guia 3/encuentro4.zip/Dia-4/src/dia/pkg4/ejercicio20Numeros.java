/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia.pkg4;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicio20Numeros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer=new Scanner (System.in);
        int nota;
        int suma = 0;
        int cont = 0;
        
        do{
          System.out.println("Ingrese la nota");
          nota=leer.nextInt();
          if (nota > 0){
            suma += nota;
          }else if (nota == 0){
            break;
          }
          cont += 1;
        }while (cont < 5);
        
        if (nota == 0){
            System.out.println("Se capturo el numero 0");
        }else{
            System.out.println("la suma de los numeros ingresados son : "+ suma);
        }
    }
}
