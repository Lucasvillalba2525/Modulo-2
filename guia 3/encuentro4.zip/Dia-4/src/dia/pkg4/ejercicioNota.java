/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia.pkg4;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicioNota {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer=new Scanner (System.in);
    int nota;
    System.out.println("ingrese la nota");
    nota=leer.nextInt();
    
    while (nota<0 || nota>10) {   
        System.out.println("Ingrese la nota nuevamente");
        nota=leer.nextInt();
       
    }
        System.out.println("la nota "+nota+" esta entre 0 y 10");
    }
}