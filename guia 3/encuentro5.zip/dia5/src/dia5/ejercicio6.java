/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia5;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        String respuesta2="n" ;
            do {
                System.out.println("Ingrese 2 numeros: ");
                int numero1 = leer.nextInt();
                int numero2 = leer.nextInt();
                
                
                System.out.println("1)sumar");
                System.out.println("2)restar");
                System.out.println("3)multiplicar");
                System.out.println("4)dividir");
                System.out.println("5)salir");
                
               int respuesta = leer.nextInt();
               
               
                
                       switch (respuesta){
                                   case 1:
                                     System.out.println("La suma es: "+(numero1+numero2));
                                     
                                     break;
  
                                   case 2:
                                       System.out.println("La resta es: "+(numero1-numero2));
                                       
                                       break;
                                       
                                   case 3:
                                       
                                       System.out.println("La respuesta es "+(numero1*numero2));
                                       
                                       break;
                                       
                                       
                                   case 4:
                                       System.out.println("La respuesta es: "+(numero1/numero2)) ;
                                       
                                       break;
                                       
                                   case 5:
                                        System.out.println("¿Está seguro que desea salir del programa (S/N)?");
                                       
                                        respuesta2 = leer.next();
                                        
                                        break ;
           
                       }
   
            } while(respuesta2.equals("n"));
                    
           System.out.println("abandono el programa");
    }
    
}
