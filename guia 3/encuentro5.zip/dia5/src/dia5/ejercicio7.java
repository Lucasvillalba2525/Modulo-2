/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia5;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer =new Scanner(System.in);
        
        int contINC = 0;
        int contCOR = 0;
        String frase = "";
        String resp = "n";
        int longfrase ; 
        
        do{
            System.out.println("ingrese una palabra");
            frase = leer.nextLine();
            longfrase = frase.length();
            String primeraL = frase.substring(0,1);
            String ultimaL = frase.substring(longfrase - 1,longfrase);
            
            if(frase.equals("&&&&&")){
                break;
            }
            
            if (longfrase == 5 && primeraL.equals("x") && ultimaL.equals("o")){
                System.out.println("CORRECTO");
                contCOR += 1;
            }else{
                System.out.println("INCORRECTO");
                contINC += 1; 
            }
            
        }while (frase != "&&&&&");
        System.out.println("la cantidad de correctas es : "+contCOR);
        System.out.println("la cantidad de incorrectas es : "+contINC);
    }
}
