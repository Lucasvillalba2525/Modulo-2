/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia5;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner leer = new Scanner(System.in);
         System.out.println("ingrese lado del cuadrado");
         int lado = leer.nextInt();
         
         for (int i = 0 ; i < lado ; i++){
             for (int j = 0; j < lado; j++){
                 if (i == 0 || i == (lado - 1) || j == 0 || j == (lado - 1)){
                     System.out.print("*");        
                 }else{
                     System.out.print(" ");
                 }
             }
             System.out.println("");
         }
         
    }
    
}
