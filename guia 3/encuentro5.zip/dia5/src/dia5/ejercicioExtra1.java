/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia5;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicioExtra1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner leer = new Scanner(System.in);
         System.out.println("ingrese minutos");
         int min = leer.nextInt();
         int dia,hora ;
         
         dia = 0;
         hora = 0;
         
         if (min > 60){
            hora = min / 60;
            if(hora > 24){
                dia = hora / 24;
                hora = hora % 24;
            }
         }
         System.out.println(dia + " dia "+hora+" hora");
    }
    
}
