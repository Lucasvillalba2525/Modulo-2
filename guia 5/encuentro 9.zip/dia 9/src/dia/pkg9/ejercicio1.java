/*Realizar un algoritmo que llene un vector con los 100 primeros números enteros
y los muestre por pantalla en orden descendente.
 */
package dia.pkg9;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int[] num = new int[10];

        for (int i = 0; i < num.length; i++) {
            num[i] = i + 1;
        }
        int aux = 10;
        for (int elemento : num) {
            System.out.println(aux);
            aux--;
        }
//        System.out.println(aux);
    }

}
