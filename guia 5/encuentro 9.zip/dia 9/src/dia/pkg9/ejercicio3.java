/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia.pkg9;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Recorrer un vector de N enteros contabilizando cuántos números son de 
        //1 dígito, cuántos de 2 dígitos, etcétera (hasta 5 dígitos).
        Scanner leer = new Scanner(System.in);
        int[] vector = new int[5];
        for (int i = 0; i < vector.length; i++) {
//            System.out.println("ingrese numeros");
//            int num = leer.nextInt();
            vector[i]= (int)(Math.random()*10000);
        }
        int longitud;
        int cont1=0,cont2=0,cont3=0,cont4=0,cont5=0;
//        int cont2 = 0;
//        int cont3 = 0;
//        int cont4 = 0;
//        int cont5 = 0;
        for (int i = 0; i < vector.length; i++) {
            longitud = Integer.toString(vector[i]).length();
//            vector[i]=longitud;
//            Integer.toString(vector[i])
            switch(longitud){
                case 1:
                    cont1++;
                    break;
                case 2:
                    cont2++;
                    break;
                case 3:
                    cont3++;
                    break;
                case 4:
                    cont4++;
                    break;
                case 5:
                    cont5++;
                    break;
            }
        }
        System.out.println("la cantidad de numeros de 1 digito es "+cont1);
        System.out.println("la cantidad de numeros de 2 digito es "+cont2);
        System.out.println("la cantidad de numeros de 3 digito es "+cont3);
        System.out.println("la cantidad de numeros de 4 digito es "+cont4);
        System.out.println("la cantidad de numeros de 5 digito es "+cont5);
    }
    
}
