/*
 * Realizar un algoritmo que llene un vector de tamaño N con valores aleatorios 
y le pida al usuario un número a buscar en el vector. El programa mostrará dónde
se encuentra el numero y si se encuentra repetido.
 */
package dia.pkg9;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int[] vector = new int[5];
        
        for (int i = 0; i < vector.length; i++) {
            vector[i]= (int)(Math.random()*10);
        }
        System.out.println("ingrese numero a buscar");
        int numB = leer.nextInt();
        int cont = 0;
        int posicion=0;
        for (int i = 0; i < vector.length; i++) {
            if (vector[i] == numB ){
                cont++;
                posicion = i;  
            }
        }
        if (cont > 0) {
            System.out.println("el numero: "+numB+" se encontro por ultima vez en: "+posicion+" repetido: "+cont);
        }else{
            System.out.println("no se encontro el numero buscado : "+numB);
        }
    }
    
}
