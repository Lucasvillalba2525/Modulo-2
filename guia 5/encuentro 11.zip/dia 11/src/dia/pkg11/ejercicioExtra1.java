/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia.pkg11;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicioExtra1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Realizar un algoritmo que calcule la suma de todos los elementos de un
        //vector de tamaño N, con los valores ingresados por el usuario.
        Scanner leer = new Scanner(System.in);
        System.out.println("ingrese numeros");
        int[] vector = new int[5];
        int suma = 0;
        for (int i = 0; i < vector.length; i++) {
            vector[i] = leer.nextInt();
            suma += vector[i];
        }
        System.out.println("la suma de los numeros ingresados es : "+suma);
    }
    
}
