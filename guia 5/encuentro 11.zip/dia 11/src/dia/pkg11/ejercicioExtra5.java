/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia.pkg11;

/**
 *
 * @author User
 */
public class ejercicioExtra5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Realizar un programa que llene una matriz de tamaño NxM con valores 
        //aleatorios y muestre la suma de sus elementos.
        int[][] matriz = new int[2][2];
        int suma = 0;
        for (int[] matriz1 : matriz) {
            for (int j = 0; j < matriz.length; j++) {
                matriz1[j] = (int) (Math.random()*10);
                suma += matriz1[j];
            }
        }
        for (int[] matriz1 : matriz) {
            for (int j = 0; j < matriz.length; j++) {
                System.out.print("[" + matriz1[j] + "]");
            }
            System.out.println("");
        }
        System.out.println("");
        System.out.println("la sumatoria de los numeros es : "+suma);
        
    }
    
}
