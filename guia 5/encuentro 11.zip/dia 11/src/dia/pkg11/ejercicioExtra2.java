/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia.pkg11;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicioExtra2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Escriba un programa que averigüe si dos vectores de N enteros son iguales
        //(la comparación deberá detenerse en cuanto se detecte alguna diferencia entre los elementos).
        Scanner leer = new Scanner(System.in);
        System.out.println("ingrese numeros del vector1");
        int[] vector1 = new int[3];
        for (int i = 0; i < vector1.length; i++) {
            vector1[i] = leer.nextInt();
        }
        System.out.println("ingrese numeros del vector2");
        int[] vector2 = new int[3];
        for (int i = 0; i < vector2.length; i++) {
            vector2[i] = leer.nextInt();
        }
        int cont = 0;
        for (int i = 0; i < vector1.length; i++) {
            if (vector1[i] == vector2[i]) {
                cont += 1;
            }else{
                System.out.println("los numeros son desiguales");
                break;
            }
        }
        if (cont == vector1.length) {
            System.out.println("los numeros son iguales");
            System.out.println("fin");
        }else{
            System.out.println("fin");
        }
    }
    
}
