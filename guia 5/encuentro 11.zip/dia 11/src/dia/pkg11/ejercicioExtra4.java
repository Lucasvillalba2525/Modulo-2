/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia.pkg11;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicioExtra4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);

        double[][] notas = new double[10][4];
        double[] promedios = new double[2];

        int aprobados = 0;
        int desaprobados = 0;

        for (int i = 0; i < promedios.length; i++) {
            System.out.println("Ingrese las notas del alumno " + (i + 1));
            
            double tpe1 = leer.nextDouble();
            double tpe2 = leer.nextDouble();
            double pi1 = leer.nextDouble();
            double pi2 = leer.nextDouble();

            double promedio = (tpe1 * 0.1 + tpe2 * 0.15 + pi1 * 0.25 + pi2 * 0.5);

            promedios[i] = promedio;
            System.out.println(promedio);
            if (promedio >= 7) {
                aprobados++;
            } else {
                desaprobados++;
            }
        }

        System.out.println("Cantidad de aprobados: " + aprobados);
        System.out.println("Cantidad de desaprobados: " + desaprobados);
    }
}
