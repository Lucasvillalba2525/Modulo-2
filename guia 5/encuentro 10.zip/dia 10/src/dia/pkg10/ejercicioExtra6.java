/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia.pkg10;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicioExtra6 {

    /**
     * Construya un programa que lea 5 palabras de mínimo 3 y hasta 5 caracteres
     * y, a medida que el usuario las va ingresando, construya una “sopa de
     * letras para niños” de tamaño de 20 x 20 caracteres. Las palabras se
     * ubicarán todas en orden horizontal en una fila que será seleccionada de
     * manera aleatoria. Una vez concluida la ubicación de las palabras, rellene
     * los espacios no utilizados con un número aleatorio del 0 al 9. Finalmente
     * imprima por pantalla la sopa de letras creada. Nota: Para resolver el
     * ejercicio deberá investigar cómo se utilizan las siguientes funciones de
     * Java substring(), Length() y Math.random().
     * @param args
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        char[][] sopa = new char[20][20];
        String palabras;
        int valor;
        int fila = (int) (Math.random() * 10);
        for (int j = 0; j < 20; j++) {
            for (int k = 0; k < 20; k++) {
                valor = (int) (Math.random() * 10);
                sopa[j][k] = (Integer.toString(valor)).charAt(0);
            }
        }
        System.out.println("ingrese 5 palabras de mínimo 3 y hasta 5 caracteres");
        for (int i = 0; i < 5; i++) {
            System.out.println("Ingrese la palabra nro" + (i + 1));
            palabras = IntroPal();
            llenar(palabras, sopa, fila);
            fila += 2;

        }
        for (int j = 0; j < 20; j++) {
            for (int k = 0; k < 20; k++) {
                System.out.print(sopa[j][k] + " ");
            }
            System.out.println("");
        }
    }

    public static String IntroPal() {
        Scanner leer = new Scanner(System.in);
        String pal;
        do {
            System.out.println("Ingrese una palabra");
            pal = leer.next();
        } while (pal.length() < 3 || pal.length() > 5);
        return pal;
    }

    public static void llenar(String palabras, char[][] sopa, int fila) {
        String b;

        int colum = (int) (Math.random() * 10);
        for (int i = 0; i < palabras.length(); i++) {
            b = palabras.substring(i, i + 1);
            sopa[fila][colum] = b.charAt(0);
            colum++;
        }

    }

}
