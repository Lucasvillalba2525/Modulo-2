/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia.pkg10;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicioExtra6 {

    /**
     * Construya un programa que lea 5 palabras de mínimo 3 y hasta 5 caracteres
     * y, a medida que el usuario las va ingresando, construya una “sopa de letras 
     * para niños” de tamaño de 20 x 20 caracteres. Las palabras se ubicarán todas
     * en orden horizontal en una fila que será seleccionada de manera aleatoria.
     * Una vez concluida la ubicación de las palabras, rellene los espacios no 
     * utilizados con un número aleatorio del 0 al 9. Finalmente imprima por pantalla
     * la sopa de letras creada.
      Nota: Para resolver el ejercicio deberá investigar cómo se utilizan las siguientes
     *funciones de Java substring(), Length() y Math.random().
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        char[][] matriz = new char [20] [20];
        String[] palabras = new String [5];
        System.out.println("ingrese 5 palabras de mínimo 3 y hasta 5 caracteres");
        for (int i = 0; i < palabras.length; i++) {
           palabras[i] = leer.next();
           //otra manera:
//            if (palabras[i].length() < 3 || palabras[i].length() > 5) {
//                System.out.println("palabra fuera de rango");
//                System.out.println("ingrese nuevamente la palabra");
//                i--;
//            }
           while(palabras[i].length() < 3 || palabras[i].length() > 5){
                System.out.println("palabra fuera de rango");
                System.out.println("ingrese nuevamente la palabra");
                palabras[i] = leer.next();
           }
        }
        System.out.println("");
        for (int i = 0; i < palabras.length; i++) {
            System.out.println(palabras[i]);
        }
        
        
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                matriz[Math.random()*20][j]= palabras[i].charAt(j);
            }
        }
    }
    
}
