/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia.pkg10;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        
        int[][] matriz = new int[3][3];
        for (int[] matriz1 : matriz) {
            for (int j = 0; j < matriz.length; j++) {
                System.out.println("ingrese numeros");
                matriz1[j] = leer.nextInt();
            }
        }
        for (int[] matriz1 : matriz) {
            for (int j = 0; j < matriz.length; j++) {
                System.out.print("[" + matriz1[j] + "]");
            }
            System.out.println("");
        }
        System.out.println("");
        for (int j = 0; j < matriz.length; j++) {
            for (int[] matriz1 : matriz) {
                System.out.print("[" + matriz1[j] + "]");
            }
            System.out.println("");
        }
        System.out.println("");
        int cont=0;
        for (int i = 0; i < matriz.length;i++) {
            for (int j = 0; j < matriz.length; j++) {
                if (matriz[i][j] == -matriz[j][i]) {
                    cont ++ ;
                }
            }
            System.out.println("");
        }
        if (cont == 9) {
            System.out.println("la matriz es antisimetrica");
        }else{
            System.out.println("la matriz no es antisimetrica");
        }
    }

}
