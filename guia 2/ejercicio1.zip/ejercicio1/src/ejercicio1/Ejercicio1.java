/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);
        System.out.println("ingrese 2 numeros");
        int num1 = num.nextInt();
        int num2 = num.nextInt();
        System.out.println("la suma de los numeros ingresados es : "+ (num1 + num2));
    }
    
}
