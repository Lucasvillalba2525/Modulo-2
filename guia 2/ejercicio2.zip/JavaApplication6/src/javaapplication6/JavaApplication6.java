
package javaapplication6;
 import java.util.Scanner;
 import javax.swing.JOptionPane;
public class JavaApplication6 {
    public static void main(String[] args) {
       /*Escribir un programa que pida dos números enteros por teclado y calcule la suma de los dos.
El programa deberá después mostrar el resultado de la suma*/

Scanner scan = new Scanner(System.in);
//       System.out.println("ingrese un numero");
//       
//        int n  = scan.nextInt();
//        System.out.println("el numero ingresado es "+n);
//        int n2 = scan.nextInt();
//        System.out.println("el numero ingresado es "+n2);
//        
//        System.out.println("la suma es " );
//        
//        
//       int num = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero"));
//       int num2 = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero"));
//       
//       int suma = num+ num2;
//       JOptionPane.showMessageDialog(null, suma);
       
//Scanner scan = new Scanner(System.in);
//
//        String nombre = JOptionPane.showInputDialog("ingrese el nombre");
//        
//        JOptionPane.showMessageDialog(null, nombre);
// 
//        System.out.println(nombre.toLowerCase()); 
//        System.out.println(nombre.toUpperCase());

//La fórmula correspondiente es: F = 32 + (9 * C / 5).


//    int grados = Integer.parseInt(JOptionPane.showInputDialog("ingrese la cantidad de grados"));
//    
//    int f = 32+(9* grados / 5);
//    
//    JOptionPane.showMessageDialog(null, f);
//    
// Escribir un programa que lea un número entero por teclado y muestre por pantalla el doble, 
// el triple y la raíz cuadrada de ese número. 
// Nota: investigar la función Math.sqrt().
    
    //int grados = Integer.parseInt(JOptionPane.showInputDialog("ingrese la cantidad de grados"));
    
    double numero = Double.parseDouble(JOptionPane.showInputDialog("ingrese un numero"));
    
       System.out.println("el doble es "+numero*2+" el triple es "+ numero*3+" la raiz cuadrada es "+ Math.sqrt(numero));
    }
    
}
