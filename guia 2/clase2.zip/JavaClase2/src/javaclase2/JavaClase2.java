
package javaclase2;

import java.util.Scanner;

class JavaClase2 {

    public static void main(String[] args) {
        
      Scanner leer = new Scanner(System.in);      
     /*Crear un programa que dado un número determine si es par o impar.
*/
  
//        
//            System.out.println("Ingrese un numero para verificar si es par: ");
//            
//            int numero1 = leer.nextInt();
//            
//          if (numero1%2==0){
//              System.out.println("El numero es par");
//          }else{
//              System.out.println("El numero no es par") ; }

/*
Crear un programa que pida una frase y si esa frase es igual a “eureka” el programa pondrá un mensaje de Correcto, 
sino mostrará un mensaje de Incorrecto. Nota: investigar la función equals() en Java.
*/
//        System.out.println("Ingrese una frase: ");
//        String frase = leer.next();
//    
//        if (frase.equals("eureka"))
//        System.out.println("Correcto");
//        else{
//                 System.out.println("Incorrecto"); }
//    
        
/*
Realizar un programa que solo permita introducir solo frases o palabras de 8 de largo. Si el usuario ingresa una frase o palabra de 8 de largo
se deberá de imprimir un mensaje por pantalla que diga “CORRECTO”, 
en caso contrario, se deberá imprimir “INCORRECTO”. Nota: investigar la función Lenght() en Java.
*/   
//        System.out.println("Ingrese una frase: ");
//        String frase = leer.next();
//        
//        if (frase.length()<= 8)
//            System.out.println("Correcto");
//        else{
//            System.out.println("Incorrecto");
//        }
               
/*
Escriba un programa que pida una frase o palabra y valide si la primera letra de esa frase es una ‘A’.
Si la primera letra es una ‘A’, se deberá de imprimir un mensaje por pantalla que diga “CORRECTO”,
en caso contrario, se deberá imprimir “INCORRECTO”. Nota: investigar la función Substring y equals() de Java.
*/
//                System.out.println("Ingrese una frase: ");
//           
//               String frase =leer.next();
  //            if (frase.substring(0,1).equals("a")){
//                    System.out.println("Correcto");
//                }else{
//                    System.out.println("Incorrecto");
 //                   }
 
/*
 Escriba un programa en el cual se ingrese un valor límite positivo, y a continuación solicite números al usuario hasta que la suma de los números
 introducidos supere el límite inicial
 */ 
 
//               System.out.println("Ingrese el numero maximo de la suma");
//               int max = leer.nextInt();
//        int suma=0;
//          
//               do {
//                   System.out.println("Ingrese un numero para sumar:");
//                   int numero = leer.nextInt();
//          
//                suma =   suma+numero;
//                           
//               }while (suma <max);
//                      System.out.println("La suma supero el numero maxuimo con "+suma);
   
/*
Realizar un programa que pida dos números enteros positivos por teclado y muestre por pantalla el siguiente menú:
El usuario deberá elegir una opción y el programa deberá mostrar el resultado por pantalla y luego volver al menú. 
El programa deberá ejecutarse hasta que se elija la opción 5. Tener en cuenta que, si el usuario selecciona la opción 5, 
en vez de salir del programa directamente, se debe mostrar el siguiente mensaje de confirmación: 
¿Está seguro que desea salir del programa (S/N)? Si el usuario selecciona el carácter ‘S’ se sale del programa, 
caso contrario se vuelve a mostrar el menú.
*/
String respuesta2="n" ;
            do {
                System.out.println("Ingrese 2 numeros: ");
                int numero1 = leer.nextInt();
                int numero2 = leer.nextInt();
                
                
                System.out.println("1)sumar");
                System.out.println("2)restar");
                System.out.println("3)multiplicar");
                System.out.println("4)dividir");
                System.out.println("5)salir");
                
               int respuesta = leer.nextInt();
               
               
                
                       switch (respuesta){
                                   case 1:
                                     System.out.println("La suma es: "+(numero1+numero2));
                                     
                                     break;
  
                                   case 2:
                                       System.out.println("La resta es: "+(numero1-numero2));
                                       
                                       break;
                                       
                                   case 3:
                                       
                                       System.out.println("La respuesta es "+(numero1*numero2));
                                       
                                       break;
                                       
                                       
                                   case 4:
                                       System.out.println("La respuesta es: "+(numero1/numero2)) ;
                                       
                                       break;
                                       
                                   case 5:
                                        System.out.println("¿Está seguro que desea salir del programa (S/N)?");
                                       
                                        respuesta2 = leer.next();
                                        
                                        break ;
                              
                                       
                                       
                       }
                       
                 
                            
                
            } while(respuesta2.equals("n"));
                    
           System.out.println("abandono el programa");    

    } 
}
        
