/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia7;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        System.out.println("ingrese nombre");
        String nombre = leer.nextLine();

        while (!(nombre.equals("no"))) {

            System.out.println("ingrese la edad");
            int edad = leer.nextInt();
            MayoriaDeEdad(nombre, edad);
            System.out.println("escriba NO para dejar de ingresar datos, de lo contrario ingrese un nombre");
            nombre = leer.next();
        }

    }

    public static void MayoriaDeEdad(String nombre, int edad) {
        if (edad >= 18) {
            System.out.println(nombre + " es mayor de edad " + edad);
        } else {
            System.out.println(nombre + " es menor de edad " + edad);
        }

    }
}
