/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia7;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int num;
        System.out.println("Ingrese un numero:");
        num = leer.nextInt();
        System.out.println("Es primo: " + esPrimo(num));
    }
    public static boolean esPrimo(int a) {
        int contador = 0;
        boolean resultado = false;
        for (int i = a; i > 0; i--) {
            if (a % i == 0) {
                contador ++;
            }
        }
        if (contador == 2 ) {
            resultado = true;
        }
        
        return resultado;
    }
}
