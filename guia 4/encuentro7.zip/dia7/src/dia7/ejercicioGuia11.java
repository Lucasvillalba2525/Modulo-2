/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia7;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicioGuia11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        System.out.println("ingrese una frase");
        String frase = leer.nextLine();
        
        String retorno = fraseNueva(frase);
        System.out.println(retorno);
    }
        
    public static String fraseNueva(String frase){
        String frase2 = frase;
        for (int i = 0; i < frase.length(); i++){
            String cadena = frase.substring(i,i+1);
            switch (cadena){
              case "a":
                frase2.concat("@");
                break;
//            case "á":
              default:
                frase2.concat(cadena);
            }
        }
        return frase2;
    }

}
