/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dia7;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner leer = new Scanner(System.in);
        System.out.println("ingrese dos numeros");
        int num1 = leer.nextInt();
        int num2 = leer.nextInt();
        int opcion;
        do{
            System.out.println("ingrese una opcion :");
            System.out.println("1_sumar");
            System.out.println("2_restar");
            System.out.println("3_multiplicar");
            System.out.println("4_dividir");
            System.out.println("5_finalizar");
            opcion = leer.nextInt();
            switch (opcion){
                case 1: 
                    System.out.println(sumar(num1,num2));
                    break;
                case 2: 
                    System.out.println(restar(num1,num2));
                    break;
                case 3: 
                    System.out.println(multiplicar(num1,num2));
                    break;
                case 4: 
                    System.out.println(dividir(num1,num2));
                    break;
            }
        }while(opcion != 5);
        System.out.println("Programa finalizado ");
}
    public static int sumar (int a, int b){
        int rta= a + b;
        return rta;
    }
    public static int restar (int a, int b){
        int rta = a-b;
        return rta;
    }
    public static int multiplicar (int a, int b){
        int rta = a*b;
        return rta;
    }
    public static double dividir (double a, double b){
        double rta = a/b;
        return rta;
    }
}