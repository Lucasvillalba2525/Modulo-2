/*
 * Crea una aplicación que a través de una función nos convierta una cantidad de
euros introducida por teclado a otra moneda, estas pueden ser a dólares, yenes o
libras. La función tendrá como parámetros, la cantidad de euros y la moneda a convertir
que será una cadena, este no devolverá ningún valor y mostrará un mensaje indicando el cambio (void).
 */
package dia7;

import static dia7.ejercicio1.dividir;
import static dia7.ejercicio1.multiplicar;
import static dia7.ejercicio1.restar;
import static dia7.ejercicio1.sumar;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        System.out.println("ingrese cantidad de euros");
        int moneda = leer.nextInt();
        String opcion;
        do{
            System.out.println("");
            System.out.println("ingrese una opcion :\ndolar"  );
            System.out.println("dolar");
            System.out.println("yenes");
            System.out.println("libras");
            System.out.println("salir");
            opcion = leer.next();
            switch (opcion){
                case "dolar": 
                    menu(moneda,opcion);
                    break;
                case "yenes": 
                    menu(moneda,opcion);;
                    break;
                case "libra": 
                    menu(moneda,opcion);
                    break;
            }
        }while(!(opcion.equals("salir")));
        System.out.println("programa finalizado");
    }
//    El cambio de divisas es:
//* 0.86 libras es un 1 €
//* 1.28611 $ es un 1 €
//* 129.852 yenes es un 1 €

    public static void menu(float a ,String opc){
        switch(opc){
            case "dolar":
                System.out.println("el cambio de divisas es:");
                System.out.println("1.28611 $ es un 1 €");
                System.out.println(opc+" : "+ a * 1.28611);
                System.out.printf("%.2f",a * 1.28611);
                break;
            case "yenes":
                System.out.println("el cambio de divisas es:");
                System.out.println("129.852 yenes es un 1 €");
                System.out.println(opc+" : "+ a * 129.852);
                System.out.println(opc+" : "+(float)((int)(a * 129.852 * 100))/100);
                break;
            case "libra":
                System.out.println("el cambio de divisas es:");
                System.out.println("0.86 $ es un 1 €");
                System.out.println(opc+" : "+ a * 0.86);
                break;
        }
    }
}
