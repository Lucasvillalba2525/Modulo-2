/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciosguia2;
import java.util.Scanner; //Importar la clase Scanner

/**
 *
 * @author victr
 */
public class ejercicio1 {
    //Escribir un programa que pida dos números enteros por teclado y calcule
//la suma de los dos. El programa deberá después mostrar el resultado de
//la suma
    /*public static void main(String[] args) {
        Scanner leer = new Scanner (System.in); //Crear el Scanner
        System.out.println("Ingrese el 1º número entero");
        int num1 = leer.nextInt(); //Leer el entero ingresado
        System.out.println("Ingrese el 2º número entero");
        int num2 = leer.nextInt(); //Leer el entero ingresado
        System.out.println("La suma de los dos números es: " + (num1 + num2));
    }
    */
}
