/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciosguia2;
import java.util.Scanner;

/**
 *
 * @author victr
 */
public class ejercicio4 {
    public static void main(String[] args) {
        /*Dada una cantidad de grados centígrados se debe mostrar su
        equivalente en grados Fahrenheit. La fórmula correspondiente es: 
        F = 32 + (9 * C / 5).
        */
        Scanner leer = new Scanner (System.in);
        System.out.println("Ingrese la temperatura en grados Celsius: ");
        double gradosC = leer.nextDouble();
        System.out.println("La temperatura en grados Fahrenheit es: " + (32 + (9 * gradosC / 5)));
    }
    
}
